package com.example.scnulibrarysdkdemo;

import java.util.List;

import com.apexism.librarysdk.bean.Book;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


/**
 * ListView ������
 * 
 * @author Adamearth
 *
 */
public class ListViewAdapter extends BaseAdapter{

	Context mContext;
	List<Book> mDatas;
	
	public ListViewAdapter(Context context, List<Book> mDatas)  
    {  

        this.mContext = context;  
        this.mDatas = mDatas;  
    } 
	
	@Override
	public int getCount() {
		// TODO �Զ����ɵķ������
		return mDatas.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO �Զ����ɵķ������
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO �Զ����ɵķ������
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO �Զ����ɵķ������
		
		Book data = mDatas.get(position);
		
		convertView = LayoutInflater.from(mContext).inflate(R.layout.listvie_item, parent, false);
		
		TextView name = (TextView) convertView.findViewById(R.id.name);
		name.setText(data.getName());
		
	      
		return convertView;
	}
	
	

}
